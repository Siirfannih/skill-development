import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {NETRAL, HURUF, RADIUS, TURUNAN} from './tema';
import {CURVE} from '../../lib/curves';

export type Kata = {w: string; t: number};
export type KtItem = {peran: string; kode: string; dari: number; sampai: number; x: number; y: number; ukuran: number; teks: string; kata: Kata[]; jangkar: string};

// K-05 (Irfan 25 Nov 2026): caption kata per kata di pelat putih membulat, pita bawah y 1250-1450, kata aktif #1F4FCC (TURUNAN.primer.tekan).
export const Caption: React.FC<{kt: KtItem[]}> = ({kt}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const k = kt.find((e) => t >= e.dari && t < e.sampai);
  if (!k) return null;
  const lines = k.teks.split('\n');
  const lf = (t - k.dari) * fps;
  if (k.peran === 'r6') {
    // cap pembuka: kata hero distempel (T04 scale-down settle 300%->100%, 9 frame)
    const p = Math.min(1, lf / 9);
    const e = CURVE.reveal(p);
    const sc = 3 - 2 * e;
    return (
      <div style={{position: 'absolute', left: 0, right: 0, top: k.y, textAlign: 'center', fontFamily: HURUF.keluarga.judul, fontWeight: HURUF.bobot.kunci, fontSize: HURUF.ukuran.hero, letterSpacing: '-0.04em', color: NETRAL.tinta, transform: `scale(${sc})`, transformOrigin: '50% 50%', opacity: p > 0 ? 1 : 0}}>
        {k.teks}
      </div>
    );
  }
  // word-pop (T19): +1..4 f setelah onset, scale .9->1 naik sedikit
  let idx = 0;
  const aktif = k.kata.reduce((a, w, i) => (t >= w.t ? i : a), 0);
  const pop = Math.min(1, lf / 4);
  const ep = CURVE.land(pop);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: k.y - 28, display: 'flex', justifyContent: 'center', transform: `translateY(${(1 - ep) * 14}px) scale(${0.94 + 0.06 * ep})`}}>
      <div style={{background: NETRAL.putih, borderRadius: RADIUS.pelat + 12, padding: '22px 40px', textAlign: 'center', fontFamily: HURUF.keluarga.judul, fontWeight: HURUF.bobot.kunci, fontSize: k.ukuran, letterSpacing: '-0.022em', lineHeight: 1.02, color: NETRAL.tinta, boxShadow: '0 10px 22px rgba(27,35,48,.30)'}}>
        {lines.map((ln, li) => (
          <div key={li}>
            {ln.split(' ').map((w, wi) => {
              const gi = idx++;
              return <span key={wi} style={{color: gi === aktif ? TURUNAN.primer.tekan : NETRAL.tinta}}>{w}{wi < ln.split(' ').length - 1 ? ' ' : ''}</span>;
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
